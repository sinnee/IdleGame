using UnityEditor;

[CustomEditor(typeof(PlayerStatus))]
public class PlayerStatusEditor : CharacterStatusEditor
{
	
}